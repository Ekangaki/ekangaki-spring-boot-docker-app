package com.ashokit;

class SbRestAppApplicationTests {

	void contextLoads() {
	}

}
